
    <header class="header-img-container">
    <?php if (!empty($hero_image)) { ?>
        <img src="/images/<?php print $hero_image; ?>" alt="" />
    <?php
}
?>
        <div class="header-info-container">
            <div class="header-info">
                <h1 class="header-info__title"><?php print $entry_title; ?>
                    <span class="header-info__description"><?php print $degree_type_full_name; ?></span>
                </h1>
                <?php if ($concentration == "Yes") {
                    print "<span class=\"header-info__concentration\">Concentration</span>";
                } ?>
                <?php if ($major == "Yes") {
                    print "<span class=\"header-info__major\">Major</span>";
                } ?>
                <?php if ($minor == "Yes") {
                    print "<span class=\"header-info__minor\">Minor</span>";
                } ?>
                <?php if ($preprofessional_programs == "Yes") {
                    print "<span class=\"header-info__preprofessional_programs\">Preprofessional Program</span>";
                } ?>
                <?php if ($allied_program == "Yes") {
                    print "<span class=\"header-info__allied_program\">Allied Program</span>";
                } ?>
                <?php print "*" . $teaching_certification . "*"; ?>
<?php if ($teaching_certification == "Yes") {
    print "<span class=\"header-info__teaching_certification\">Teaching Certification</span>";
} ?>


                <?php if ($program_format == "Online") {
                    print "<span class=\"header-info__online\">online</span>";
                } ?>
                <?php if ($program_format == "Hybrid") {
                    print "<span class=\"header-info__hybrid\">hybrid</span>";
                } ?>
                <?php if ($program_format == "Campus") {
                    print "<span class=\"header-info__campus\">campus</span>";
                } ?>
            </div>
        </div>
    </header>




    <!-- BREADCRUMB -->
    <div class="breadcrumbs-2 bread__wrap">
        <ul class="breadcrumbs-list">
            <li>
                <a href="http://www.messiah.edu/" rel="home">Home</a>
            </li>
            <li>
                <a href="https://www.messiah.edu/academics" rel="academic">Academic</a>
            </li>
            <li>
                <a href="<?php print $department_url; ?>" rel="<?php print $department_name; ?>"><?php print $department_name; ?></a>
            </li>
<?php if (!empty($parent_program)) { ?>
        <li>
                <a href="<?php print $parent_program_url; ?>"><?php print $parent_program; ?></a>
        </li>
    <?php
} ?>
            <li>
                <span><?php print $entry_title; ?></span>
            </li>
        </ul>
    </div>
    <!-- BREADCRUMB END -->


    <div id="main-content-2">
        <div class="main-holder-2">

            <div class="one-column-2">
                <div id="content">
            <!-- CONTENT -->
                    <div class="main-title clearfix">
                        <h2 class="h2-title"><?php print $entry_title; ?></h2>
                        <button class="bookmark-btn">
                            <img src="//home.messiah.edu/~khardy/prototype/grad-program/files/images/program_page_images/bookmark-icon.png" alt="bookmark icon" class="bookmark-img">
                            <span>Bookmark This</span>
                        </button>
                    </div>

                    <div class="page-description">
                        <p><?php print $program_overview; ?></p>
                    </div>

                    <div class="page-tab">
                        <button class="tab-btn overview-btn" onclick="loadContent(event, 'overview',<?php print $overview_tab_id; ?>,'<?php print $program_name; ?>','at Messiah College')" id="overview">Overview</button>
                        <button class="tab-btn courses-btn" onclick="loadContent(event, 'courses',<?php print $courses__curriculum_tab_id; ?>,'<?php print $program_name; ?>','courses')" id="courses"><?php print $tab_courses_name; ?></button>
                        <button class="tab-btn tuition-btn" onclick="loadContent(event, 'tuition',<?php print $career_and_outcomes_tab_id; ?>,'<?php print $program_name; ?>','careers and outcomes')" id="tuition-aid">Career and Outcomes</button>
                        <button class="tab-btn apply-btn" onclick="loadContent(event, 'apply',<?php print $learning_by_doing_tab_id; ?>,'<?php print $program_name; ?>','')" id="how-to-apply">Learn By Doing</button>
                        <button class="tab-btn why-messiah-btn" onclick="loadContent(event, 'why-messiah',3280,'<?php print $program_name; ?>','')" id="why-messiah">Why Messiah?</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="tab-content-container">
        <div id="main-content-2">
            <div class="main-holder-2">
                <div class="one-column-2">
                    <div id="content">

                        <!-- OVERVIEW TAB -->
                        <div id="Content" class="tabcontent">

                            <!-- LEFT COLUMN -->
                            <div class="tabcontent-col-left">
                                    [Dynamic Content Here]
                            </div>
                        </div>
                        <!-- RIGHT COLUMN -->
                        <div class="form-col-right">
                            <div class="info-panel">
                                <a href="<?php print $department_url; ?>" class="view-homepage-btn overlay-color">
                                    <p class="btn-upper-text">Department of
                                    <span class="btn-bottom-text"><?php print $department_name; ?></span></p>
                                </a>
                                <a href="<?php print $meet_the_faculty_url; ?>" class="meet-faculty-btn overlay-color">
                                    <p class="btn-upper-text">meet the
                                    <span class="btn-bottom-text">Faculty</span></p>
                                </a>
                                 <a href="<?php print $view_our_facilities_url; ?>" class="view-homepage-btn overlay-color ">
                                    <p class="btn-upper-text">View our
                                    <span class="btn-bottom-text">Facilities</span></p>
                                </a>
                                <a href="#" class="btn-blue btn-white">
                                    <img src="./files/images/program_page_images/request-info-icon.png" alt="request information icon" class ="request-icon" >
                                    <span> Request Info </span>
                                </a>
                                <a href="#" class ="btn-white">
                                    <img src = "//home.messiah.edu/~khardy/prototype/grad-program/files/images/program_page_images/apply-icon.png" alt="apply button icon" class ="apply-icon">
                                    <span>Apply</span>
                                </a>
                                <a href="#" class="btn-white">
                                    <img src = "//home.messiah.edu/~khardy/prototype/grad-program/files/images/program_page_images/chat-icon.png" alt="chat online icon" class ="chat-online-icon" >
                                    <span> Chat Online </ span >
                                </a>
                                <a href = "#" class ="btn-white" >
                                    <img src = "./files/images/program_page_images/admission-requirements-icon.png" alt="admissions icon" class="admissions-icon" >
                                    <span > Admission Requirements </ span >
                                </a>
                                <a href = "#" class ="btn-white" >
                                    <img src = "./files/images/program_page_images/tuition-icon-20.png" alt="tuition icon" class="tuition-icon" >
                                    <span > Tuition </ span >
                                </a>
                                <a href = "#" class ="btn-white" >
                                    <img src = "./files/images/program_page_images/scholarships-icon.png" alt="scholarships icon" class="scholarships-icon" >
                                    <span > Scholarships </ span >
                                </a>

                            </div>
                        </div>

                    <!--CONTENT END -->
                    </div>
                </div>
            </div>
        </div>
    </div>
